require('./Admin');
require('./Blogs');
require('./Product');
require('./Contact');
require('./Device');
 